public class MainApp {
    public static <status_pendidikan> void main(String[] args){
        karyawan karyawan=new karyawan("Amir", "kabol", "087861234567");

        penggajian penggajian=new penggajian("Rp.8.700.000", "Rp. 5. 400.000", "Rp.4.400.000");

        //status_pendidikan status_pendidikan=new stts_pendidikan(("Aktif");

        jabatan jabatan=new jabatan("Teacher");

        karyawan.cetakkaryawan(karyawan.no_hp);
        penggajian.cetakpenggajian(penggajian.gajiPokok);
        jabatan.cetakjabatan(jabatan.jabatan);
        //status_pendidikan(status_pendidikan(("status");

    }

}
