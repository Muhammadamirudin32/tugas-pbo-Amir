public class jabatan {
    String jabatan;

    jabatan(String paranjabatan_pegawai){
        this.jabatan = paranjabatan_pegawai;
    }

    void cetakjabatan(String jabatan){
        System.out.println("Jabatan = "+ jabatan);
    }



}
