public class stts_pendidikan {
    String status = "Aktif";
    stts_pendidikan(String paranstatus){
        this.status = paranstatus;
    }

    void cetakstatus_pendidikan(String status){
        System.out.println("status = "+ status);
    }

}

